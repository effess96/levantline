# Business Landing Page Template v1.0

One file: `index.html`. No installs, no build step.

## 1. Edit your details (5 minutes)
Open `index.html` in any text editor. Edit ONLY the block between
`/* ===== BIZ: edit everything here ===== */` and `/* ===== end of edit area ===== */`.
- `name`, `tag`, `headline`, `sub`: each has `en` and `ar` text.
- `whatsapp`: number with country code, digits only (e.g. 9627XXXXXXXX).
- `phone`, `currency`, `mapLink` (paste your Google Maps share link).
- `hours`, `services` (icon, name, description, price), `why` (3-4 selling points).
- `theme`: "light" or "dark". `showThemeButton`: true/false.
Keep the quotes and commas. Delete a service by deleting its `{...},` line.

## 2. Preview
Double-click `index.html` to open it in your browser. Tap the language button to check Arabic (right-to-left switches automatically).

## 3. Put it online (free options)
GitHub Pages, Netlify Drop, Cloudflare Pages, or any web host: upload `index.html`.

## 4. Test the WhatsApp button
Tap "Book on WhatsApp": it should open your chat with a ready message. If not, check the `whatsapp` number format.

## Changelog
v1.0 first release: EN/AR, light/dark toggle, WhatsApp booking, hours, services, map.

Licence: you may use it for your own business or your clients' sites. Do not resell or share the template file itself.
